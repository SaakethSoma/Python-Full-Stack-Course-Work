from setuptools import setup

setup(
    name="QRCode-Scanner",
    version="1.0",
    author="Logadheep",
    author_email="logadheep3438@gmail.com",
    description="QRcode Scanning app using python",
)
